# Angular 7/8/9 Application with PHP Back-End Example

Angular 7/8/9 Application with PHP Back-End

For details on how to implement and run this project see:

[Angular 9/8 with PHP and MySQL RESTful CRUD Example & Tutorial](https://www.techiediaries.com/angular/angular-9-php-mysql-database/)


[Angular 9/8 with PHP: Consuming a RESTful CRUD API with HttpClient and Forms](https://www.techiediaries.com/angular/php-angular-9-crud-api-httpclient/)
