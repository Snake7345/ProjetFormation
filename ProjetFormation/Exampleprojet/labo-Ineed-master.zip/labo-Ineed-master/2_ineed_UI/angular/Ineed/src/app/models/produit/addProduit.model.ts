export class addProduit {
    id : number
    nom : string
    description : string
    prix : number
    quantite : number
    categorieId : number
    entrepreneurId : number
}