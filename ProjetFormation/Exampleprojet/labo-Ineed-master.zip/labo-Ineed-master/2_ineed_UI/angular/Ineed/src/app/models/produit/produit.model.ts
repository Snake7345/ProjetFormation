export class produit {
    id : number
    nom : string
    description : string
    prix : number
    quantite : number
    estDisponible : boolean
    categorieId : number
    entrepreneurId : number
}