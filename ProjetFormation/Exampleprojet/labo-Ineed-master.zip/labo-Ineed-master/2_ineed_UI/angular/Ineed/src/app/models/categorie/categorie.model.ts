export class categorie {
    id : number
    nom : string
}