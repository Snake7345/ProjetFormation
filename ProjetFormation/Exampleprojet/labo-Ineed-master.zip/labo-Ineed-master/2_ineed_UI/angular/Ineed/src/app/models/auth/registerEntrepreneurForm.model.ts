export class registerEntrepreneurForm {
    nomE: string
    numeroRueE : number
    rueE : string
    villeE : string
    codePostalE : number
    email : string
    utilisateurId : number
    image : File
}