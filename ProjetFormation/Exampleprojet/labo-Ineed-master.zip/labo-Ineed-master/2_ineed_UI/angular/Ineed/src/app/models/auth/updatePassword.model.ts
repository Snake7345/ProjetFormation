export class updatePassword {
    oldPassword: string
    newPassword: string
    comfirmNewPassword: string
}