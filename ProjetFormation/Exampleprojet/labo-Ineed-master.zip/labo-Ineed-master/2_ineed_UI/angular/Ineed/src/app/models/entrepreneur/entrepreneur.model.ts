export class entrepreneur {
    id: number
    nomE: string
    numeroRueE : number
    rueE : string
    villeE : string
    codePostalE : number
    utilisateurId : number
}