export class loginForm {
    email : string
    password : string
}