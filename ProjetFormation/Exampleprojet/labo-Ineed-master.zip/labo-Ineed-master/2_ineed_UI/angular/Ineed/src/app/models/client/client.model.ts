export class client {
    id : number
    nom: string
    prenom : string
    dateNaissance : Date
    numeroRue : number
    rue : string
    ville : string
    codePostal : number
    email : string
    password : string
    token : string
}