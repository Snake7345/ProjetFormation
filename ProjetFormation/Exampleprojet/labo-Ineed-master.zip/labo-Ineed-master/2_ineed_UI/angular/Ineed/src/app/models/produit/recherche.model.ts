export class recherche {
    recherche : string
}