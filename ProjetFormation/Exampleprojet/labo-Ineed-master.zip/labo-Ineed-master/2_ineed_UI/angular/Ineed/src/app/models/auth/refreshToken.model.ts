export class refreshToken {
    refreshToken : string
}