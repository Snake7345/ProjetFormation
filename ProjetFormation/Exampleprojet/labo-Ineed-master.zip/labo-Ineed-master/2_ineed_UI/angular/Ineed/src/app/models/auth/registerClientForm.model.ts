export class registerClientForm {
    nom: string
    prenom : string
    dateNaissance : Date
    numeroRue : number
    rue : string
    ville : string
    codePostal : number
    email : string
    password : string
    etat : boolean
}