export class ligneCommande {
    id: number
    quantite: string
    prix : number
    commandeId : string
    produitId : string
}