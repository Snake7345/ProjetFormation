export class commande {
    id : number
    prix: number
    clientId : number 
}