export class imageProduit {
    name : any
    htmlObj : any
    fileImg : any
}