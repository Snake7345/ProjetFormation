insert into roles (id, role) values (1, 'utilisateur');
insert into roles (id, role) values (2, 'entrepreneur');
insert into roles (id, role) values (3, 'modérateur');
insert into roles (id, role) values (4, 'administrateur');